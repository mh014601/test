<?php

namespace app\api\model;

use think\model\Pivot;

class MemberCourse extends Pivot
{
    
}
