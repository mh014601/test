<?php
 phpinfo();
?>