<?php
//000000007200
 exit();?>
think_serialize:a:3:{s:5:"phone";s:11:"18300644045";s:4:"code";s:4:"1234";s:7:"version";s:2:"v1";}