<?php
//000000007200
 exit();?>
think_serialize:a:1:{i:0;a:12:{s:2:"id";i:1;s:8:"username";s:5:"xiao1";s:8:"password";s:32:"b5c97f4747cd6dfa9ab5886eab27ab9d";s:6:"avatar";s:38:"/uploads/avatar/157871233919375813.jpg";s:5:"email";N;s:6:"mobile";s:11:"18300644045";s:5:"money";N;s:3:"mid";i:1;s:4:"type";i:1;s:5:"price";d:10;s:5:"stime";i:1234567898;s:5:"etime";i:1234567899;}}