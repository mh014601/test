<?php

namespace app\api\controller\v2;

use think\Controller;
use think\Request;

class Ticket extends Controller
{
    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function getTicket()
    {
        return "get ticket2";
    }




}
